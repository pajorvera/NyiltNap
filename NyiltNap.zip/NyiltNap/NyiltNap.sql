CREATE DATABASE  IF NOT EXISTS `nyiltnap` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `nyiltnap`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: nyiltnap
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jelentkezes_szak`
--

DROP TABLE IF EXISTS `jelentkezes_szak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jelentkezes_szak` (
  `id` int(10) unsigned NOT NULL,
  `jelentkezes_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`,`jelentkezes_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jelentkezes_szak`
--

LOCK TABLES `jelentkezes_szak` WRITE;
/*!40000 ALTER TABLE `jelentkezes_szak` DISABLE KEYS */;
/*!40000 ALTER TABLE `jelentkezes_szak` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jelentkezesek`
--

DROP TABLE IF EXISTS `jelentkezesek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jelentkezesek` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nev` varchar(150) NOT NULL,
  `iskola` varchar(150) NOT NULL,
  `kollegista` tinyint(1) NOT NULL,
  `vegzos` tinyint(1) NOT NULL,
  `regisztracio_ideje` datetime NOT NULL,
  `szakok` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jelentkezesek`
--

LOCK TABLES `jelentkezesek` WRITE;
/*!40000 ALTER TABLE `jelentkezesek` DISABLE KEYS */;
INSERT INTO `jelentkezesek` VALUES (10,'Simon Marcell','Reguly Antall Általános Iskola',1,1,'2026-10-13 12:00:48','[\"Pénzügyi-számviteli ügyintéző\"]'),(11,'asdf','dfrgth',0,1,'2026-10-13 14:58:00','[\"Szerszám- és készülékgyártó\"]'),(12,'ukhkujhjk','zouzzo',1,0,'2026-10-13 14:58:19','[\"Pénzügyi-számviteli ügyintéző\"]');
/*!40000 ALTER TABLE `jelentkezesek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `szakok`
--

DROP TABLE IF EXISTS `szakok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `szakok` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nev` varchar(45) DEFAULT NULL,
  `sorrend` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `szakok`
--

LOCK TABLES `szakok` WRITE;
/*!40000 ALTER TABLE `szakok` DISABLE KEYS */;
/*!40000 ALTER TABLE `szakok` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-13 15:38:29
