<?php
require_once 'conn.php';
$siker = false;
$hiba = '';

$elérhetőSzakok = [
    "CNC-programozó",
    "Mechatronikai technikus",
    "Mechatronikus karbantartó",
    "Pénzügyi-számviteli ügyintéző",
    "Szerszám- és készülékgyártó",
    "Szoftverfejlesztő és -tesztelő"
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nev = trim($_POST['nev'] ?? '');
    $iskola = trim($_POST['iskola'] ?? '');
    $kiválasztottSzakok = $_POST['szakok'] ?? [];
    $kollegista = intval($_POST['kollegista'] ?? 0);
    $vegzos = intval($_POST['vegzos'] ?? 0);

    if (empty($nev) || empty($iskola) || empty($kiválasztottSzakok)) {
        $hiba = 'Kérlek tölts ki minden mezőt és válassz ki legalább egy szakot!';
    } else {
        $szakokSzoveg = json_encode($kiválasztottSzakok, JSON_UNESCAPED_UNICODE);

        try {
            $stmt = $pdo->prepare("INSERT INTO jelentkezesek (nev, iskola, szakok, kollegista, vegzos, regisztracio_ideje) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$nev, $iskola, $szakokSzoveg, $kollegista, $vegzos]);
            $siker = true;
        } catch (Exception $e) {
            $hiba = 'Hiba történt az adatbázisba mentés során: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nyílt Nap Regisztráció | Nádasdy Tamás Technikum</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .brand-bg { background-color: #0f1d36; }
        .brand-gradient { background: linear-gradient(135deg, #0f1d36 0%, #1e3a6a 100%); }
    </style>
</head>
<body class="bg-slate-900 text-slate-100 min-h-screen flex flex-col justify-between font-sans selection:bg-blue-600 selection:text-white">
    
    <!-- Fejléc a logó színvilágához igazítva -->
    <header class="brand-gradient text-white shadow-xl border-b border-blue-900/50">
        <div class="max-w-4xl mx-auto px-6 py-6 flex items-center justify-between">
            <div class="flex items-center space-x-4">
                <img src="logo.png" alt="Nádasdy Logó" class="w-14 h-14 object-contain rounded-2xl shadow-md bg-blue-950/80 p-1.5 border border-blue-700/30">
                <div>
                    <h1 class="text-xl md:text-2xl font-bold tracking-wide text-blue-50">Nádasdy Tamás Technikum</h1>
                    <p class="text-blue-200/80 text-xs md:text-sm">Nyílt Napok - Regisztrációs Portál</p>
                </div>
            </div>
            <a href="admin.php" class="text-xs bg-blue-900/60 hover:bg-blue-800 border border-blue-700/40 px-4 py-2.5 rounded-xl text-blue-100 transition shadow-sm">Admin Belépés</a>
        </div>
    </header>

    <main class="max-w-2xl w-full mx-auto px-4 py-10 flex-grow">
        <div class="bg-slate-800/90 backdrop-blur rounded-3xl shadow-2xl border border-slate-700/60 p-6 md:p-10">
            <div class="mb-8 text-center">
                <h2 class="text-2xl md:text-3xl font-extrabold text-white tracking-tight">Szia Érdeklődő! 👋</h2>
                <p class="text-slate-400 mt-2 text-sm">Töltsd ki az alábbi űrlapot a jelentkezéshez.</p>
            </div>

            <?php if ($siker): ?>
                <div class="bg-emerald-950/60 border border-emerald-800/60 text-emerald-200 p-6 rounded-2xl text-center space-y-3 shadow-inner">
                    <div class="text-4xl">🎉</div>
                    <h3 class="font-bold text-lg text-emerald-100">Sikeres regisztráció!</h3>
                    <p class="text-sm text-emerald-300">Köszönjük jelentkezésed, várunk szeretettel!</p>
                    <a href="index.php" class="inline-block mt-2 bg-emerald-600 hover:bg-emerald-500 text-white px-6 py-2.5 rounded-xl text-sm font-semibold transition shadow-lg">Új regisztráció</a>
                </div>
            <?php else: ?>
                <?php if ($hiba): ?>
                    <div class="mb-6 bg-rose-950/70 border border-rose-800/60 text-rose-200 p-4 rounded-xl text-sm font-medium text-center">
                        <?= htmlspecialchars($hiba) ?>
                    </div>
                <?php endif; ?>

                <form action="index.php" method="POST" class="space-y-6">
                    <div>
                        <label class="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">Teljes neved:</label>
                        <input type="text" name="nev" required placeholder="pl. Kovács Anna" 
                               class="w-full px-4 py-3.5 rounded-xl bg-slate-900/80 border border-slate-700 text-slate-100 placeholder-slate-500 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition text-base">
                    </div>

                    <div>
                        <label class="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">Jelenlegi iskolád:</label>
                        <input type="text" name="iskola" required placeholder="pl. Petőfi Sándor Ált. Iskola" 
                               class="w-full px-4 py-3.5 rounded-xl bg-slate-900/80 border border-slate-700 text-slate-100 placeholder-slate-500 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition text-base">
                    </div>

                    <div>
                        <label class="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">Érdeklődési szak(ok): (többet is választhatsz)</label>
                        <div class="grid grid-cols-1 gap-2.5 bg-slate-900/60 p-4 rounded-2xl border border-slate-700/80">
                            <?php foreach ($elérhetőSzakok as $szakNev): ?>
                                <label class="flex items-center space-x-3 p-2.5 hover:bg-slate-800 rounded-xl cursor-pointer transition border border-transparent hover:border-slate-700">
                                    <input type="checkbox" name="szakok[]" value="<?= htmlspecialchars($szakNev) ?>" 
                                           class="w-5 h-5 accent-blue-600 rounded border-slate-700 bg-slate-900">
                                    <span class="text-sm font-medium text-slate-200"><?= htmlspecialchars($szakNev) ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">Lakhatás:</label>
                            <select name="kollegista" required class="w-full px-4 py-3.5 rounded-xl bg-slate-900/80 border border-slate-700 text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none text-base">
                                <option value="" class="bg-slate-900">-- Válassz --</option>
                                <option value="0" class="bg-slate-900">Bejárós</option>
                                <option value="1" class="bg-slate-900">Kollégista</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">Végzős vagy?</label>
                            <select name="vegzos" required class="w-full px-4 py-3.5 rounded-xl bg-slate-900/80 border border-slate-700 text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none text-base">
                                <option value="" class="bg-slate-900">-- Válassz --</option>
                                <option value="1" class="bg-slate-900">Igen</option>
                                <option value="0" class="bg-slate-900">Nem</option>
                            </select>
                        </div>
                    </div>

                    <div class="pt-4">
                        <button type="submit" class="w-full brand-gradient hover:opacity-95 text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-950 transition text-base border border-blue-600/30">
                            Jelentkezés elküldése 🚀
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </main>

    <footer class="text-center py-6 text-xs text-slate-500 border-t border-slate-800">
        &copy; 2026 Nádasdy Tamás Technikum - Minden jog fenntartva.
    </footer>

</body>
</html>