<?php
session_start();
require_once 'conn.php';

if (!isset($pdo)) {
    die("Hiba: Az adatbázis kapcsolat (\$pdo) nem jött létre.");
}

$elérhetőSzakok = [
    "CNC-programozó",
    "Mechatronikai technikus",
    "Mechatronikus karbantartó",
    "Pénzügyi-számviteli ügyintéző",
    "Szerszám- és készülékgyártó",
    "Szoftverfejlesztő és -tesztelő"
];

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit;
}

$loginHiba = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $felhasznalo = trim($_POST['username'] ?? '');
    $jelszo = $_POST['password'] ?? '';

    $adminUser = 'admin';
    $adminPassHash = password_hash('admin123', PASSWORD_DEFAULT);

    if ($felhasznalo === $adminUser && password_verify($jelszo, $adminPassHash)) {
        $_SESSION['admin_logged_in'] = true;
        header("Location: admin.php");
        exit;
    } else {
        $loginHiba = 'Hibás felhasználónév vagy jelszó!';
    }
}

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true):
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Bejelentkezés | Nádasdy Technikum</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .brand-gradient { background: linear-gradient(135deg, #0f1d36 0%, #1e3a6a 100%); }
    </style>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen flex items-center justify-center font-sans">
    <div class="bg-slate-900 p-8 rounded-3xl shadow-2xl border border-slate-800 max-w-md w-full">
        <div class="text-center mb-6">
            <img src="logo.png" alt="Logó" class="w-16 h-16 object-contain mx-auto mb-3 rounded-2xl bg-blue-950/80 p-1.5 border border-blue-700/30 shadow-inner">
            <h1 class="text-xl font-bold text-white">Adminisztrációs Belépés</h1>
            <p class="text-xs text-slate-400 mt-1">Nádasdy Tamás Technikum</p>
        </div>

        <?php if ($loginHiba): ?>
            <div class="mb-4 bg-rose-950/70 border border-rose-800/60 text-rose-200 p-3 rounded-xl text-xs font-medium text-center">
                <?= htmlspecialchars($loginHiba) ?>
            </div>
        <?php endif; ?>

        <form action="admin.php" method="POST" class="space-y-4">
            <div>
                <label class="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">Felhasználónév</label>
                <input type="text" name="username" required class="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none text-sm">
            </div>
            <div>
                <label class="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">Jelszó</label>
                <input type="password" name="password" required class="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none text-sm">
            </div>
            <button type="submit" name="login" class="w-full brand-gradient hover:opacity-95 text-white font-bold py-3.5 rounded-xl shadow-lg transition text-sm border border-blue-600/30">
                Belépés
            </button>
        </form>
        <div class="mt-6 text-center">
            <a href="index.php" class="text-xs text-blue-400 hover:text-blue-300 transition">← Vissza a főoldalra</a>
        </div>
    </div>
</body>
</html>
<?php
    exit;
endif;

if (isset($_GET['torol'])) {
    $id = intval($_GET['torol']);
    $stmt = $pdo->prepare("DELETE FROM jelentkezesek WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: admin.php");
    exit;
}

$stmt = $pdo->query("SELECT * FROM jelentkezesek ORDER BY regisztracio_ideje DESC");
$jelentkezesek = $stmt->fetchAll();

$osszesJelentkezo = count($jelentkezesek);
$szakStatisztika = [];
$vegzosSzakStatisztika = [];
$koleszosOsszesen = 0;
$koleszosVegzos = 0;
$bejarosOsszesen = 0;
$bejarosVegzos = 0;

foreach ($jelentkezesek as $j) {
    if ($j['kollegista'] == 1) {
        $koleszosOsszesen++;
        if ($j['vegzos'] == 1) $koleszosVegzos++;
    } else {
        $bejarosOsszesen++;
        if ($j['vegzos'] == 1) $bejarosVegzos++;
    }

    $diakSzakok = json_decode($j['szakok'], true) ?? [];
    foreach ($diakSzakok as $sNev) {
        $szakStatisztika[$sNev] = ($szakStatisztika[$sNev] ?? 0) + 1;
        if ($j['vegzos'] == 1) {
            $vegzosSzakStatisztika[$sNev] = ($vegzosSzakStatisztika[$sNev] ?? 0) + 1;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel | Nádasdy Technikum</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .brand-gradient { background: linear-gradient(135deg, #0f1d36 0%, #1e3a6a 100%); }
    </style>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen font-sans">
    <header class="brand-gradient text-white shadow-xl border-b border-blue-900/50">
        <div class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
            <div class="flex items-center space-x-3">
                <img src="logo.png" alt="Logó" class="w-10 h-10 object-contain rounded-xl bg-blue-950/80 p-1 border border-blue-700/30">
                <h1 class="text-xl font-bold tracking-wide">Adminisztrációs Vezérlőpult</h1>
            </div>
            <div class="flex items-center space-x-3">
                <a href="index.php" class="bg-blue-900/60 hover:bg-blue-800 border border-blue-700/40 text-white px-4 py-2 rounded-xl text-sm transition">Ugrás a Formra ↗</a>
                <a href="admin.php?logout=1" class="bg-rose-950/80 hover:bg-rose-900 border border-rose-800/50 text-rose-200 px-4 py-2 rounded-xl text-sm transition">Kijelentkezés</a>
            </div>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 py-8 space-y-8">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="bg-slate-900 p-6 rounded-3xl shadow-lg border border-slate-800">
                <p class="text-xs font-semibold uppercase tracking-wider text-slate-400">Összes Jelentkező</p>
                <p class="text-3xl font-extrabold text-white mt-2"><?= $osszesJelentkezo ?></p>
            </div>
            <div class="bg-slate-900 p-6 rounded-3xl shadow-lg border border-slate-800">
                <p class="text-xs font-semibold uppercase tracking-wider text-slate-400">Kollégisták (Összes / Végzős)</p>
                <p class="text-3xl font-extrabold text-blue-400 mt-2"><?= $koleszosOsszesen ?> <span class="text-sm font-normal text-slate-500">(végzős: <?= $koleszosVegzos ?>)</span></p>
            </div>
            <div class="bg-slate-900 p-6 rounded-3xl shadow-lg border border-slate-800">
                <p class="text-xs font-semibold uppercase tracking-wider text-slate-400">Bejárósok (Összes / Végzős)</p>
                <p class="text-3xl font-extrabold text-emerald-400 mt-2"><?= $bejarosOsszesen ?> <span class="text-sm font-normal text-slate-500">(végzős: <?= $bejarosVegzos ?>)</span></p>
            </div>
            <div class="bg-slate-900 p-6 rounded-3xl shadow-lg border border-slate-800">
                <p class="text-xs font-semibold uppercase tracking-wider text-slate-400">Aktív Szakok Száma</p>
                <p class="text-3xl font-extrabold text-amber-400 mt-2"><?= count($elérhetőSzakok) ?></p>
            </div>
        </div>

        <div class="bg-slate-900 rounded-3xl shadow-lg border border-slate-800 overflow-hidden p-6">
            <h3 class="text-lg font-bold text-white mb-4">Szakok szerinti érdeklődés</h3>
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="border-b border-slate-800 text-xs font-semibold text-slate-400 uppercase tracking-wider">
                            <th class="py-3 px-4">Szak neve</th>
                            <th class="py-3 px-4">Összes jelentkező</th>
                            <th class="py-3 px-4">Ebből végzős</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-800/60 text-sm">
                        <?php foreach ($elérhetőSzakok as $szakNev): ?>
                            <tr>
                                <td class="py-3.5 px-4 font-medium text-slate-200"><?= htmlspecialchars($szakNev) ?></td>
                                <td class="py-3.5 px-4 font-bold text-blue-400"><?= $szakStatisztika[$szakNev] ?? 0 ?> fő</td>
                                <td class="py-3.5 px-4 font-bold text-emerald-400"><?= $vegzosSzakStatisztika[$szakNev] ?? 0 ?> fő</td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="bg-slate-900 rounded-3xl shadow-lg border border-slate-800 overflow-hidden p-6">
            <h3 class="text-lg font-bold text-white mb-4">Összes Regisztráció Részletesen</h3>
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="border-b border-slate-800 text-xs font-semibold text-slate-400 uppercase tracking-wider">
                            <th class="py-3 px-4">Időpont</th>
                            <th class="py-3 px-4">Név</th>
                            <th class="py-3 px-4">Iskola</th>
                            <th class="py-3 px-4">Szakok</th>
                            <th class="py-3 px-4">Lakhatás</th>
                            <th class="py-3 px-4">Végzős?</th>
                            <th class="py-3 px-4 text-right">Művelet</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-800/60 text-sm">
                        <?php if (empty($jelentkezesek)): ?>
                            <tr><td colspan="7" class="py-6 text-center text-slate-500">Még senki sem regisztrált.</td></tr>
                        <?php else: ?>
                            <?php foreach ($jelentkezesek as $j): ?>
                                <tr class="hover:bg-slate-800/50 transition">
                                    <td class="py-3.5 px-4 text-slate-400 text-xs"><?= htmlspecialchars($j['regisztracio_ideje']) ?></td>
                                    <td class="py-3.5 px-4 font-semibold text-white"><?= htmlspecialchars($j['nev']) ?></td>
                                    <td class="py-3.5 px-4 text-slate-300"><?= htmlspecialchars($j['iskola']) ?></td>
                                    <td class="py-3.5 px-4">
                                        <div class="flex flex-wrap gap-1">
                                            <?php 
                                            $diakSzakok = json_decode($j['szakok'], true) ?? [];
                                            foreach ($diakSzakok as $dsz): 
                                            ?>
                                                <span class="bg-blue-950 text-blue-300 border border-blue-800/40 text-xs px-2.5 py-1 rounded-lg font-medium"><?= htmlspecialchars($dsz) ?></span>
                                            <?php endforeach; ?>
                                        </div>
                                    </td>
                                    <td class="py-3.5 px-4">
                                        <span class="px-3 py-1 rounded-full text-xs font-semibold <?= $j['kollegista'] == 1 ? 'bg-purple-950 text-purple-300 border border-purple-800/40' : 'bg-slate-800 text-slate-300 border border-slate-700/50' ?>">
                                            <?= $j['kollegista'] == 1 ? 'Kollégista' : 'Bejárós' ?>
                                        </span>
                                    </td>
                                    <td class="py-3.5 px-4">
                                        <span class="px-3 py-1 rounded-full text-xs font-semibold <?= $j['vegzos'] == 1 ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/40' : 'bg-amber-950 text-amber-300 border border-amber-800/40' ?>">
                                            <?= $j['vegzos'] == 1 ? 'Igen' : 'Nem' ?>
                                        </span>
                                    </td>
                                    <td class="py-3.5 px-4 text-right">
                                        <a href="admin.php?torol=<?= $j['id'] ?>" onclick="return confirm('Biztosan törlöd?');" 
                                           class="text-rose-400 hover:text-rose-300 font-medium text-xs bg-rose-950/60 hover:bg-rose-900/80 border border-rose-800/40 px-3 py-1.5 rounded-xl transition inline-block">
                                            Törlés
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</body>
</html>